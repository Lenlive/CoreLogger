package de.lenlive.dragonfury;

import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.event.EventPriority;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import java.util.*;

/** All world access runs on the server thread; no block changes or real lightning. */
public final class DragonFury extends JavaPlugin implements Listener {
    private final Map<UUID, Fight> fights = new HashMap<>();
    private double health, combatRadius, rageFraction, rageMultiplier, boltDamage, boltRadius;
    private double meteorDamage, meteorRadius;
    private int normalCooldown, rageCooldown, boltWarning, meteorWarning;
    private static final class Fight {
        int remaining;
        boolean rage, lightning = true;
    }

    @Override public void onEnable() {
        saveDefaultConfig();
        health = value("health", 400, 200, 2000);
        combatRadius = value("combat-radius", 96, 16, 192);
        rageFraction = value("rage-health-fraction", .25, .1, .9);
        rageMultiplier = value("rage-damage-multiplier", 1.5, 1, 3);
        normalCooldown = (int) value("normal-cooldown-seconds", 18, 5, 300);
        rageCooldown = (int) value("rage-cooldown-seconds", 10, 5, 300);
        boltWarning = (int) value("lightning.warning-seconds", 3, 1, 10);
        boltDamage = value("lightning.damage", 8, 0, 40);
        boltRadius = value("lightning.radius", 3, 1, 8);
        meteorWarning = (int) value("meteor.warning-seconds", 4, 2, 10);
        meteorDamage = value("meteor.damage", 10, 0, 40);
        meteorRadius = value("meteor.radius", 4, 1, 8);
        getServer().getPluginManager().registerEvents(this, this);
        new EggClaim(this).start();
        getServer().getScheduler().runTaskTimer(this, this::tick, 20, 20);
    }

    private double value(String key, double fallback, double min, double max) {
        double v = getConfig().getDouble(key, fallback);
        return Double.isFinite(v) ? Math.clamp(v, min, max) : fallback;
    }

    @EventHandler public void onSpawn(CreatureSpawnEvent event) {
        if (event.getEntity() instanceof EnderDragon dragon && dragon.getWorld().getEnvironment() == World.Environment.THE_END)
            prepare(dragon, true);
    }

    private Fight prepare(EnderDragon dragon, boolean fresh) {
        return fights.computeIfAbsent(dragon.getUniqueId(), ignored -> {
            var max = dragon.getAttribute(Attribute.MAX_HEALTH);
            if (max != null) {
                double ratio = dragon.getHealth() / max.getValue();
                max.setBaseValue(health);
                dragon.setHealth(Math.max(1, Math.min(max.getValue(), fresh ? health : ratio * max.getValue())));
            }
            Fight f = new Fight();
            f.remaining = normalCooldown;
            return f;
        });
    }

    private boolean eligible(Player player) {
        return player.isOnline() && !player.isDead() &&
            (player.getGameMode() == GameMode.SURVIVAL || player.getGameMode() == GameMode.ADVENTURE);
    }

    private List<Player> targets(EnderDragon dragon) {
        double squared = combatRadius * combatRadius;
        return dragon.getWorld().getPlayers().stream().filter(this::eligible)
            .filter(p -> p.getLocation().distanceSquared(dragon.getLocation()) <= squared).toList();
    }

    private boolean alive(EnderDragon dragon) { return dragon.isValid() && !dragon.isDead() && isEnabled(); }

    private void tick() {
        Set<UUID> active = new HashSet<>();
        for (World world : getServer().getWorlds()) {
            if (world.getEnvironment() != World.Environment.THE_END) continue;
            for (EnderDragon dragon : world.getEntitiesByClass(EnderDragon.class)) {
                if (!alive(dragon)) continue;
                active.add(dragon.getUniqueId());
                Fight f = prepare(dragon, false);
                List<Player> players = targets(dragon);
                var max = dragon.getAttribute(Attribute.MAX_HEALTH);
                boolean rage = max != null && dragon.getHealth() <= max.getValue() * rageFraction;
                if (rage && !f.rage) {
                    f.rage = true;
                    f.remaining = Math.min(f.remaining, rageCooldown);
                    players.forEach(p -> { p.sendMessage("§5§lDer Enderdrache gerät in Raserei!");
                        p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 1, .7f); });
                }
                if (players.isEmpty()) continue;
                if (--f.remaining > 0) continue;
                double damageScale = f.rage ? rageMultiplier : 1;
                if (f.lightning) lightning(dragon, players, damageScale);
                else meteors(dragon, players, damageScale);
                f.lightning = !f.lightning;
                f.remaining = f.rage ? rageCooldown : normalCooldown;
            }
        }
        fights.keySet().retainAll(active);
    }

    private void lightning(EnderDragon dragon, List<Player> players, double scale) {
        // Mark fixed positions: players can dodge; at most eight strikes per cast.
        List<Location> marks = players.stream().limit(8).map(p -> p.getLocation().clone()).toList();
        players.forEach(p -> p.sendMessage("§dDrachenblitze! Verlasse die violetten Markierungen!"));
        new BukkitRunnable() {
            int elapsed;
            @Override public void run() {
                if (!alive(dragon)) { cancel(); return; }
                for (Location mark : marks) ring(mark, boltRadius);
                if (elapsed++ < boltWarning * 4) return;
                for (Location mark : marks) dragon.getWorld().strikeLightningEffect(mark);
                // Overlapping circles never multiply damage for one player.
                for (Player p : dragon.getWorld().getPlayers()) {
                    if (eligible(p) && marks.stream().anyMatch(m -> p.getLocation().distanceSquared(m) <= boltRadius * boltRadius))
                        p.damage(boltDamage * scale, dragon);
                }
                cancel();
            }
        }.runTaskTimer(this, 0, 5);
    }

    private void meteors(EnderDragon dragon, List<Player> players, double scale) {
        List<Location> marks = players.stream().limit(8).map(p -> p.getLocation().clone()).toList();
        players.forEach(p -> p.sendMessage("§6Meteore! Verlasse die markierten Einschlagstellen!"));
        new BukkitRunnable() {
            int elapsed;
            @Override public void run() {
                if (!alive(dragon)) { cancel(); return; }
                double progress = Math.min(1, elapsed / (meteorWarning * 4.0));
                for (Location mark : marks) {
                    ring(mark, meteorRadius);
                    Location meteor = mark.clone().add(0, 24 * (1 - progress), 0);
                    mark.getWorld().spawnParticle(Particle.FLAME, meteor, 12, .3, .3, .3, .02);
                    mark.getWorld().spawnParticle(Particle.SMOKE, meteor, 5, .2, .2, .2, .01);
                }
                if (elapsed++ < meteorWarning * 4) return;
                for (Location mark : marks) {
                    mark.getWorld().spawnParticle(Particle.EXPLOSION, mark, 1);
                    mark.getWorld().playSound(mark, Sound.ENTITY_GENERIC_EXPLODE, 1, .7f);
                }
                for (Player p : dragon.getWorld().getPlayers()) {
                    if (eligible(p) && marks.stream().anyMatch(m -> p.getLocation().distanceSquared(m) <= meteorRadius * meteorRadius))
                        p.damage(meteorDamage * scale, dragon);
                }
                cancel();
            }
        }.runTaskTimer(this, 0, 5);
    }

    private void ring(Location center, double radius) {
        for (int i = 0; i < 32; i++) {
            double angle = Math.PI * 2 * i / 32;
            center.getWorld().spawnParticle(Particle.DRAGON_BREATH,
                center.getX() + Math.cos(angle) * radius, center.getY() + .15,
                center.getZ() + Math.sin(angle) * radius, 1, 0, 0, 0, 0);
        }
    }

    @Override public void onDisable() {
        getServer().getScheduler().cancelTasks(this);
        fights.clear();
    }
}
