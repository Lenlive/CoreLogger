package de.lenlive.dragonfury;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.inventory.InventoryPickupItemEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import java.util.*;

/** The real egg remains the authoritative object; visual entities are disposable. */
final class EggClaim implements Listener {
    private final JavaPlugin plugin;
    private final Map<Location, Egg> eggs = new HashMap<>();
    private final Map<UUID, Long> lastSwing = new HashMap<>();
    private int animation;
    private static final class Egg {
        final Location source;
        final UUID item;
        final EggProgress progress = new EggProgress();
        final ItemDisplay display;
        final TextDisplay label;
        Egg(Location source, UUID item, ItemDisplay display, TextDisplay label) {
            this.source = source; this.item = item; this.display = display; this.label = label;
        }
    }
    EggClaim(JavaPlugin plugin) { this.plugin = plugin; }

    void start() {
        Bukkit.getPluginManager().registerEvents(this, plugin);
        // Existing dropped eggs and eggs near players are discovered without loading chunks.
        Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 1, 5);
    }

    private boolean counts(Player p) {
        return !p.isDead() && p.getGameMode() != GameMode.SPECTATOR;
    }
    private List<Player> nearby(Location center) {
        return center.getWorld().getPlayers().stream().filter(this::counts)
            .filter(p -> p.getLocation().distanceSquared(center) <= 25).toList();
    }
    private void register(Block block) {
        if (block.getType() == Material.DRAGON_EGG) register(block.getLocation(), null);
    }
    private void register(Location source, UUID item) {
        if (eggs.containsKey(source)) return;
        Location center = source.clone().add(.5, 1.1, .5);
        ItemDisplay display = source.getWorld().spawn(center, ItemDisplay.class, e -> {
            e.setItemStack(new ItemStack(Material.DRAGON_EGG));
            e.setGlowing(true);
            e.setGlowColorOverride(Color.PURPLE);
            e.setPersistent(false);
            e.setInvulnerable(true);
            e.setBillboard(Display.Billboard.CENTER);
        });
        TextDisplay label = source.getWorld().spawn(center.clone().add(0, .9, 0), TextDisplay.class, e -> {
            e.setBillboard(Display.Billboard.CENTER);
            e.setPersistent(false);
            e.setInvulnerable(true);
            e.setSeeThrough(false);
        });
        eggs.put(source.clone(), new Egg(source.clone(), item, display, label));
    }
    private void remove(Egg egg) { egg.display.remove(); egg.label.remove(); }
    private boolean exists(Egg egg) {
        if (!egg.source.getWorld().isChunkLoaded(egg.source.getBlockX() >> 4, egg.source.getBlockZ() >> 4)) return false;
        if (egg.item == null) return egg.source.getBlock().getType() == Material.DRAGON_EGG;
        Entity entity = Bukkit.getEntity(egg.item);
        return entity instanceof Item item && item.isValid() && item.getItemStack().getType() == Material.DRAGON_EGG;
    }
    private void tick() {
        animation++;
        for (World world : Bukkit.getWorlds()) {
            for (Item item : world.getEntitiesByClass(Item.class)) {
                if (item.getItemStack().getType() != Material.DRAGON_EGG) continue;
                // Anchor the actual item: no passive pickup, drifting, merging or despawn.
                item.setGravity(false); item.setVelocity(new org.bukkit.util.Vector());
                item.setUnlimitedLifetime(true);
                if (eggs.values().stream().noneMatch(e -> item.getUniqueId().equals(e.item)))
                    register(item.getLocation().getBlock().getLocation(), item.getUniqueId());
            }
            for (Player player : world.getPlayers()) {
                // Only a small local cube is inspected, at 1 Hz; no world-wide block scan.
                if (animation % 4 != 0) continue;
                Block base = player.getLocation().getBlock();
                for (int x = -5; x <= 5; x++) for (int y = -3; y <= 3; y++) for (int z = -5; z <= 5; z++) {
                    int bx = base.getX() + x, bz = base.getZ() + z;
                    if (world.isChunkLoaded(bx >> 4, bz >> 4)) register(base.getRelative(x, y, z));
                }
            }
        }
        Iterator<Egg> iterator = eggs.values().iterator();
        while (iterator.hasNext()) {
            Egg egg = iterator.next();
            if (!exists(egg)) { remove(egg); iterator.remove(); continue; }
            Location center = egg.source.clone().add(.5, .5, .5);
            int count = nearby(center).size();
            if (count != 1) egg.progress.reset();
            boolean open = count == 1;
            egg.label.text(Component.text(count + " Spieler " + (open ? "✔" : "✖") + "  " + egg.progress.hits() + "/5",
                open ? NamedTextColor.GREEN : NamedTextColor.RED));
            egg.display.teleport(egg.source.clone().add(.5, 1.1 + .12 * Math.sin(animation * .2), .5));
        }
        lastSwing.keySet().removeIf(id -> Bukkit.getPlayer(id) == null);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void interact(PlayerInteractEvent event) {
        if (event.getClickedBlock() == null || event.getClickedBlock().getType() != Material.DRAGON_EGG) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        event.setCancelled(true); // Prevent vanilla egg teleportation, including right click.
        register(event.getClickedBlock());
        if (event.getAction() == Action.LEFT_CLICK_BLOCK)
            hit(event.getPlayer(), eggs.get(event.getClickedBlock().getLocation()));
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void preventBreak(BlockBreakEvent event) {
        if (event.getBlock().getType() == Material.DRAGON_EGG) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void pickup(EntityPickupItemEvent event) {
        if (event.getItem().getItemStack().getType() == Material.DRAGON_EGG) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void hopper(InventoryPickupItemEvent event) {
        if (event.getItem().getItemStack().getType() == Material.DRAGON_EGG) event.setCancelled(true);
    }
    @EventHandler(ignoreCancelled = true)
    public void swing(PlayerAnimationEvent event) {
        if (event.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        Player player = event.getPlayer();
        Location eye = player.getEyeLocation();
        var direction = eye.getDirection();
        RayTraceResult wall = player.getWorld().rayTraceBlocks(eye, direction, 4.5);
        double limit = wall == null ? 4.5 : wall.getHitPosition().distance(eye.toVector()) + .01;
        Egg target = null;
        double closest = limit;
        for (Egg egg : eggs.values()) {
            if (!egg.source.getWorld().equals(player.getWorld())) continue;
            Location center = egg.display.getLocation();
            var offset = center.toVector().subtract(eye.toVector());
            double along = offset.dot(direction);
            if (along < 0 || along > closest || offset.lengthSquared() - along * along > .55 * .55) continue;
            closest = along; target = egg;
        }
        if (target != null) hit(player, target);
    }

    private void hit(Player player, Egg egg) {
        if (egg == null || !exists(egg) || !counts(player)) return;
        Location center = egg.source.clone().add(.5, .5, .5);
        if (player.getLocation().distanceSquared(center) > 25) return;
        long now = player.getWorld().getFullTime();
        if (now - lastSwing.getOrDefault(player.getUniqueId(), now - 6) < 6) return;
        lastSwing.put(player.getUniqueId(), now);
        List<Player> players = nearby(center);
        boolean alone = players.size() == 1 && players.getFirst().equals(player);
        if (!alone) {
            egg.progress.reset();
            player.sendMessage("§cDu musst allein im Umkreis von 5 Blöcken um das Ei sein!");
            return;
        }
        // Require room before accepting the final hit; never drop a reward for someone else.
        if (egg.progress.hits() == 4 && player.getInventory().firstEmpty() == -1) {
            player.sendMessage("§cDu brauchst einen freien Inventarplatz!");
            return;
        }
        boolean complete = egg.progress.hit(player.getUniqueId(), true);
        player.playSound(center, Sound.BLOCK_AMETHYST_BLOCK_HIT, 1, 1 + egg.progress.hits() * .1f);
        center.getWorld().spawnParticle(Particle.DRAGON_BREATH, center, 20, .4, .5, .4, .02);
        if (!complete) return;
        ItemStack reward = new ItemStack(Material.DRAGON_EGG);
        if (egg.item != null && Bukkit.getEntity(egg.item) instanceof Item item) reward = item.getItemStack().clone();
        // Check with the actual stack too (dropped stacks may contain multiple eggs).
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(reward);
        if (!leftovers.isEmpty()) {
            // Keep only the remainder in the authoritative item, preserving every egg.
            if (egg.item != null && Bukkit.getEntity(egg.item) instanceof Item item)
                item.setItemStack(leftovers.values().iterator().next());
            egg.progress.reset();
            return;
        }
        if (egg.item == null) egg.source.getBlock().setType(Material.AIR);
        else if (Bukkit.getEntity(egg.item) instanceof Item item) item.remove();
        eggs.remove(egg.source);
        remove(egg);
        celebrate(player);
    }
    private void celebrate(Player player) {
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1, .8f);
        new BukkitRunnable() {
            int tick;
            public void run() {
                if (!player.isOnline() || player.isDead()) { cancel(); return; }
                for (int arm = 0; arm < 2; arm++) {
                    double angle = tick * .35 + arm * Math.PI;
                    Location point = player.getLocation().add(Math.cos(angle), tick / 20.0, Math.sin(angle));
                    point.getWorld().spawnParticle(Particle.DRAGON_BREATH, point, 3, .03, .03, .03, 0);
                    point.getWorld().spawnParticle(Particle.END_ROD, point, 1);
                }
                if (++tick >= 40) cancel();
            }
        }.runTaskTimer(plugin, 1, 1);
    }
    @EventHandler public void disable(PluginDisableEvent event) {
        if (event.getPlugin() != plugin) return;
        eggs.values().forEach(this::remove);
        eggs.clear(); lastSwing.clear();
    }
}
