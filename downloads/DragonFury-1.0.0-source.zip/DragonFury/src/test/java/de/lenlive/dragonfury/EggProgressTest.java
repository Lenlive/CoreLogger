package de.lenlive.dragonfury;

import java.util.UUID;

/** Run with java -ea; no server or external libraries required. */
public final class EggProgressTest {
    public static void main(String[] args) {
        UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        EggProgress progress = new EggProgress();
        for (int i = 1; i <= 4; i++) {
            assert !progress.hit(a, true) : "Reward before fifth hit";
            assert progress.hits() == i;
        }
        assert progress.hit(a, true) : "Fifth hit must complete";
        progress.reset();
        progress.hit(a, true); progress.hit(a, true);
        assert !progress.hit(b, true);
        assert progress.hits() == 1 : "Another player must not inherit progress";
        assert !progress.hit(b, false);
        assert progress.hits() == 0 : "Contested hits must reset progress";
        for (int i = 0; i < 4; i++) assert !progress.hit(a, true);
        assert !progress.hit(a, false) : "Other player on final hit must block reward";
        assert progress.hits() == 0;
        for (int i = 0; i < 4; i++) assert !progress.hit(a, true);
        assert progress.hit(a, true);
        progress.reset();
        assert progress.hits() == 0;
        assert !progress.hit(b, true);
        System.out.println("PASS: five hits, no early reward, separate claimants, contested reset, blocked final hit, retry, explicit reset");
    }
}
