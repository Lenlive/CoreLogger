# DragonFury 1.0.0

Separates Plugin für Paper 26.3 und Java 25. Bestehende Plugins bleiben unverändert.

## Gewählte Fähigkeiten

- 400 Lebenspunkte (200 Herzen). Bei bereits vorhandenen Drachen bleibt der prozentuale Lebensstand beim ersten Erfassen erhalten.
- Drachenblitze: feste violette Zielkreise, 3 Sekunden Vorwarnung, 8 Schadenspunkte.
- Meteore: Partikelgeschosse mit festen Zielkreisen, 4 Sekunden Vorwarnung, 10 Schadenspunkte und 4 Blöcke Radius. Keine echten Explosionen, kein Feuer und keine Blockschäden durch die neuen Angriffe.
- Wutphase ab 25 % Leben (100 Lebenspunkte): Spezialangriffe alle 10 statt 18 Sekunden, 1,5-facher Fähigkeitsschaden. Die Wutphase bleibt für den laufenden Kampf aktiv, auch bei Heilung; nach einem Plugin-/Serverneustart wird sie anhand des aktuellen Lebensstands neu bestimmt.
- Normaler Drachenatem und Kristallheilung bleiben erhalten. Keine Schockwelle und keine beschworenen Endermänner.
- Angriffe betreffen Überlebens- und Abenteuerspieler; maximal acht feste Zielpositionen pro Angriff. Überlappende Kreise verursachen pro Angriff nur einmal Schaden.

## Drachenei

Das Ei erhält eine schwebende Darstellung mit violetter Leuchtumrandung und sanfter Auf-/Abbewegung. Darüber steht die Spieleranzahl im 5-Block-Radius, bei genau einem Spieler ein grünes ✔, sonst ein rotes ✖, plus Schlagfortschritt `0/5` bis `5/5`. Darstellung mit Vanilla-Display-Entities, kein Ressourcenpaket erforderlich; Schrift und Eiform entsprechen der Vanilla-Darstellung und können vom Beispielbild abweichen.

**Fünf Linksklicks/Schläge** auf das schwebende Ei oder seinen echten Ei-Block sind zum Einsammeln nötig. Jeder Schlag zählt nur, wenn der Schlagende allein innerhalb von einschließlich fünf Blöcken um das Ei ist. Bei einem zweiten Spieler wird der Fortschritt zurückgesetzt. Ein anderer Spieler beginnt seine eigene Schlagfolge bei null. Zwischen gezählten Schlägen liegen mindestens sechs Ticks (0,3 Sekunden bei 20 TPS).

Lebende Spieler einschließlich Kreativspielern zählen, Zuschauer nicht. Die Entfernung wird räumlich um das Ei gemessen, auch durch Wände. Auch fallengelassene Ei-Items benötigen die fünf Schläge; normale Aufnahme und Trichteraufnahme sind gesperrt. Das Ei kann nicht durch normales Anklicken teleportiert oder im Kreativmodus abgebaut werden. Beim fünften Schlag landet es direkt im Inventar, sofern Platz vorhanden ist. Anschließend erscheinen zwei violett-weiße Partikelspiralen und ein Erfolgssound.

Die echten Ei-Blöcke/Items bleiben bis zur Vergabe erhalten. Anzeige und Fortschritt werden nach Neustarts neu aufgebaut; Fortschritt startet bei null. Anzeigen werden nur in geladenen Chunks und in Spielernähe aufgebaut.

## Bauen und installieren

Java 25 und Maven 3.9+ benötigen Zugriff auf Maven Central und das offizielle Paper-Maven-Repository.

```sh
cd /workspace/CoreLogger/DragonFury
mvn --batch-mode package
```

Danach `target/dragon-fury-1.0.0.jar` nach `plugins/` kopieren und Paper vollständig neu starten. Einstellungen entstehen in `plugins/DragonFury/config.yml`; Änderungen erfordern einen Neustart.

## Prüfstatus

Die reine Schlagfortschrittslogik wurde mit Java 25 und aktivierten Assertions geprüft: fünfter Schlag, kein vorzeitiger Erhalt, Spielerwechsel, umkämpfter Radius, blockierter fünfter Schlag, erneuter Versuch und Zurücksetzen bestanden. Der vollständige Plugin-Code wurde gegen die echte Paper-API 26.3.build.224-stable mit Java 25 erfolgreich kompiliert. JAR-Struktur, Hauptklasse, Konfiguration und Java-25-Bytecode geprüft. Die main-basierte Schlagfortschrittsprüfung wurde explizit mit aktivierten Assertions ausgeführt; der Maven-Testlauf allein führt sie nicht aus. Kein Live-Test auf einem Minecraft-Server durchgeführt.

Noch auf einem Testserver zu prüfen: frischen Drachen, 25%-Grenze, Vorwarnung/Ausweichen beider Angriffe, Blockunversehrtheit, Kampfende während Vorwarnung, Ei-Anzeige/Leuchtfarbe, fünf Schläge allein, Fortschrittsreset bei zweitem Spieler und Spielerwechsel, Sichtlinienprüfung, Ei-Vergabe genau einmal, Chunkwechsel/Neustart, volles Inventar und Trichterblockierung prüfen.
