# DragonFury – Fabric-Modpack

Minecraft **1.21.1**, Fabric Loader **0.16.14**, Fabric API **0.116.17+1.21.1**, Java **21 oder neuer**.

## Einfach importieren

`DragonFury-1.0.0-mc1.21.1.mrpack` herunterladen und in die Modrinth-App ziehen. Alternativ in der App eine Instanz aus Datei importieren. Der Import installiert Fabric, die Fabric API und DragonFury. Anschließend die Instanz starten und eine neue Einzelspielerwelt öffnen oder einen passenden Fabric-Server betreten.

Dies ist eine echte Fabric-Mod, keine umbenannte Paper-JAR. Die Paper-Ausgabe für 26.3 bleibt unabhängig. Minecraft-Welten aus 26.3 dürfen nicht mit 1.21.1 geöffnet werden.

## Multiplayer und NoRisk

Für die Regeln im Multiplayer muss **der Server ebenfalls Minecraft 1.21.1 mit Fabric, Fabric API und der DragonFury-Fabric-JAR** verwenden. Ein reines Client-Modpack kann die Regeln auf einem fremden Server nicht aktivieren. Paper-Plugins funktionieren auf einem Fabric-Server nicht.

Das `.mrpack`-Paket ist für den Modrinth-Import vorgesehen. Kompatibilität und Import in NoRisk wurden nicht geprüft; kein zugesicherter NoRisk-Import.

## Funktionen

- 400 Lebenspunkte. Bei vorhandenen Drachen wird beim ersten Erfassen der prozentuale Lebensstand erhalten.
- Drachenblitze: violette Zielkreise, drei Sekunden Vorwarnung, acht Schadenspunkte, drei Blöcke Radius.
- Meteore: fallende Feuer-/Rauchpartikel, vier Sekunden Vorwarnung, zehn Schadenspunkte, vier Blöcke Radius. Keine Blockschäden oder Brände durch die zusätzlichen Fähigkeiten.
- Wutphase ab 25 % Leben (100 von 400): Fähigkeiten alle zehn statt achtzehn Sekunden und 1,5-facher Fähigkeitsschaden. Für den laufenden Kampf bleibt die Wutphase aktiv; nach einem Neustart wird sie anhand des Lebensstands neu bestimmt.
- Normaler Drachenatem und Kristallheilung bleiben. Keine Schockwelle, keine beschworenen Endermänner.
- Spezialangriffe betreffen lebende Überlebens-/Abenteuerspieler, höchstens acht Zielpositionen. Überlappende Kreise verursachen pro Angriff nur einmal Schaden.
- Drachenei: schwebende Darstellung mit violetter Umrandung, roter Spieleranzahl und ✖ beziehungsweise grünem ✔ bei genau einem Spieler innerhalb von einschließlich fünf Blöcken; Schlagfortschritt `0/5`.
- Fünf Schläge bei mindestens sechs Ticks Abstand, ausschließlich wenn der Schlagende allein im Radius ist. Andere Spieler oder ein Wechsel des alleinstehenden Spielers setzen den Fortschritt zurück. Lebende Kreativspieler zählen, Zuschauer nicht. Räumlicher Radius, auch durch Wände.
- Fünfter Schlag: Vergabe direkt ins Inventar, sofern Platz vorhanden ist; zweisekündige violett-weiße Doppelspirale und Erfolgssound. Auch fallengelassene Ei-Items benötigen fünf Schläge. Keine passive Aufnahme und keine Aufnahme durch Trichter.
- Vanilla-Ei-Teleportation per Rechtsklick und normaler Abbau sind gesperrt. Anzeigen und Schlagfortschritt werden nach einem Neustart neu aufgebaut.

Die Anzeige nutzt Vanilla-Display-Entities. Schrift und Eiform können ohne spezielles Ressourcenpaket vom Beispielbild abweichen.

## Konfiguration

`config/dragonfury.json` wird beim ersten Start erstellt. Lebenspunkte, Wutschwelle, Fähigkeitsschaden und Abklingzeiten können dort geändert werden. Danach die Einzelspielerwelt bzw. den Server vollständig neu starten.

## Entwicklung und Tests

Gradle 9.2.1 und JDK 25 werden für den getesteten Build verwendet; das Ergebnis verwendet Java-21-Bytecode. Der Build lädt Minecraft und Fabric von ihren offiziellen Quellen und Maven-Abhängigkeiten aus den konfigurierten Repositories.

```sh
gradle build
```

Der Build führt Minecraft-GameTests aus. Diese verwenden eine separate Testwelt unter `build/run/gameTest`. Sie wird nicht als Spielstand mitgeliefert. Der Testmod und seine Hilfsspieler sind nicht Bestandteil der veröffentlichten Mod.

Build und sechs erforderliche Minecraft-GameTests bestanden: fünf Schläge bis zur Vergabe über den echten Abbau-Handler, Sperre bei zweitem Spieler, keine passive Aufnahme, Trichterschutz, getrennte Schlagfolgen/Reset sowie 400 Lebenspunkte und die Wutphasen-Grenze bei 25 %. Im Grenzwerttest wird die natürliche Kristallheilung kontrolliert, damit der Lebensstand stabil bleibt.

Ein visueller Test im Minecraft-Client oder NoRisk-Launcher wurde nicht durchgeführt. Einen vorhandenen produktiven Server zunächst sichern und die Mod in einer Testwelt ausprobieren.
