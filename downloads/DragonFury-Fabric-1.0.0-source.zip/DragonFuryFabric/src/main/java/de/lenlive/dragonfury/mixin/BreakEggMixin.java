package de.lenlive.dragonfury.mixin;
import de.lenlive.dragonfury.DragonFuryMod;
import net.minecraft.block.Blocks;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.network.ServerPlayerInteractionManager;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(ServerPlayerInteractionManager.class)
public abstract class BreakEggMixin {
    @Shadow @Final protected ServerPlayerEntity player;
    @Inject(method = "tryBreakBlock", at = @At("HEAD"), cancellable = true)
    private void dragonfury$break(BlockPos pos, CallbackInfoReturnable<Boolean> ci) {
        if (player.getServerWorld().getBlockState(pos).isOf(Blocks.DRAGON_EGG)) {
            DragonFuryMod.INSTANCE.hitBlock(player, pos); ci.setReturnValue(false);
        }
    }
}
