package de.lenlive.dragonfury.mixin;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(HopperBlockEntity.class)
public abstract class HopperEggMixin {
    @Inject(method = "extract(Lnet/minecraft/inventory/Inventory;Lnet/minecraft/entity/ItemEntity;)Z", at = @At("HEAD"), cancellable = true)
    private static void dragonfury$hopper(Inventory inventory, ItemEntity item, CallbackInfoReturnable<Boolean> ci) {
        if (item.getStack().isOf(Items.DRAGON_EGG)) ci.setReturnValue(false);
    }
}
