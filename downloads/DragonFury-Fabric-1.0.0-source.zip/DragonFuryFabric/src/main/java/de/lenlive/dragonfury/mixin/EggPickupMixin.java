package de.lenlive.dragonfury.mixin;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ItemEntity.class)
public abstract class EggPickupMixin {
    @Inject(method = "onPlayerCollision", at = @At("HEAD"), cancellable = true)
    private void dragonfury$pickup(PlayerEntity player, CallbackInfo ci) {
        if (((ItemEntity)(Object)this).getStack().isOf(Items.DRAGON_EGG)) ci.cancel();
    }
}
