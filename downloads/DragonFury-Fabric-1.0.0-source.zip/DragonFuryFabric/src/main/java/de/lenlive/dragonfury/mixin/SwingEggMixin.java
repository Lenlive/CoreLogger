package de.lenlive.dragonfury.mixin;
import de.lenlive.dragonfury.DragonFuryMod;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(ServerPlayNetworkHandler.class)
public abstract class SwingEggMixin {
    @Shadow public ServerPlayerEntity player;
    @Inject(method = "onHandSwing", at = @At("TAIL"))
    private void dragonfury$swing(HandSwingC2SPacket packet, CallbackInfo ci) {
        if (packet.getHand() == Hand.MAIN_HAND) DragonFuryMod.INSTANCE.swing(player);
    }
}
