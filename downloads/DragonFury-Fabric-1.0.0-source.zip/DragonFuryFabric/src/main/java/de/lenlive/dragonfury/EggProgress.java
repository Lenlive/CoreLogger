package de.lenlive.dragonfury;

import java.util.UUID;

/** Per-egg claim progress. Contention or a different claimant starts a new sequence. */
final class EggProgress {
    private UUID claimant;
    private int hits;
    void reset() { claimant = null; hits = 0; }
    int hits() { return hits; }
    boolean hit(UUID player, boolean alone) {
        if (!alone) { reset(); return false; }
        if (!player.equals(claimant)) { claimant = player; hits = 0; }
        return ++hits >= 5;
    }
}
