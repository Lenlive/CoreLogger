package de.lenlive.dragonfury;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.UUID;

public class DragonFuryGameTests implements FabricGameTest {
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE)
    public void progressRules(TestContext context) {
        EggProgress p = new EggProgress(); UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        for (int i = 0; i < 4; i++) context.assertTrue(!p.hit(a, true), "Must not reward before fifth hit");
        context.assertTrue(p.hit(a, true), "Fifth hit must reward"); p.reset();
        p.hit(a, true); p.hit(a, true); p.hit(b, true);
        context.assertTrue(p.hits() == 1, "Player cannot inherit another player's hits");
        context.assertTrue(!p.hit(b, false) && p.hits() == 0, "Contested hit must reset");
        context.complete();
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 160)
    public void fiveHitsAndNoTeleport(TestContext context) {
        BlockPos relative = new BlockPos(1, 2, 1);
        for (int x = 0; x < 4; x++) for (int z = 0; z < 4; z++) context.setBlockState(new BlockPos(x, 1, z), Blocks.STONE);
        context.setBlockState(relative, Blocks.DRAGON_EGG);
        BlockPos pos = context.getAbsolutePos(relative);
        ServerPlayerEntity player = context.createMockCreativeServerPlayerInWorld();
        player.refreshPositionAfterTeleport(Vec3d.ofCenter(pos).add(1, 0, 0));
        for (int i = 0; i < 5; i++) {
            final int step = i;
            context.runAtTick(10 + 8 * i, () -> {
                player.interactionManager.tryBreakBlock(pos);
                if (step < 4) context.assertTrue(context.getWorld().getBlockState(pos).isOf(Blocks.DRAGON_EGG), "Egg disappeared early");
            });
        }
        context.runAtTick(55, () -> {
            context.assertTrue(context.getWorld().getBlockState(pos).isAir(), "Egg not collected after five hits");
            context.assertTrue(player.getInventory().count(Items.DRAGON_EGG) == 1, "Must give exactly one egg");
            player.discard(); context.complete();
        });
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 100)
    public void otherPlayerBlocksCollection(TestContext context) {
        BlockPos relative = new BlockPos(1, 2, 1);
        for (int x = 0; x < 4; x++) for (int z = 0; z < 4; z++) context.setBlockState(new BlockPos(x, 1, z), Blocks.STONE); context.setBlockState(relative, Blocks.DRAGON_EGG);
        BlockPos pos = context.getAbsolutePos(relative);
        ServerPlayerEntity a = context.createMockCreativeServerPlayerInWorld();
        ServerPlayerEntity b = context.createMockCreativeServerPlayerInWorld();
        a.refreshPositionAfterTeleport(Vec3d.ofCenter(pos).add(1, 0, 0));
        b.refreshPositionAfterTeleport(Vec3d.ofCenter(pos).add(-1, 0, 0));
        for (int i = 0; i < 5; i++) context.runAtTick(10 + 8 * i, () -> DragonFuryMod.INSTANCE.hitBlock(a, pos));
        context.runAtTick(55, () -> {
            context.assertTrue(context.getWorld().getBlockState(pos).isOf(Blocks.DRAGON_EGG), "Contested egg must remain");
            context.assertTrue(a.getInventory().count(Items.DRAGON_EGG) == 0, "No contested reward");
            a.discard(); b.discard(); context.complete();
        });
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 100)
    public void passivePickupBlocked(TestContext context) {
        ServerPlayerEntity player = context.createMockCreativeServerPlayerInWorld();
        ItemEntity item = context.spawnItem(Items.DRAGON_EGG, new BlockPos(1, 2, 1));
        item.resetPickupDelay(); player.refreshPositionAfterTeleport(item.getPos());
        context.runAtTick(30, () -> {
            item.onPlayerCollision(player);
            context.assertTrue(item.isAlive() && !item.isRemoved(), "Passive pickup bypassed five hits");
            context.assertTrue(player.getInventory().count(Items.DRAGON_EGG) == 0, "Passive pickup gave egg");
            item.discard(); player.discard(); context.complete();
        });
    }

    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 180)
    public void dragonHealthAndRageBoundary(TestContext context) {
        var end = context.getWorld().getServer().getWorld(net.minecraft.world.World.END);
        context.assertTrue(end != null, "End dimension unavailable");
        end.setChunkForced(0, 0, true);
        end.getChunk(0, 0);
        var dragon = EntityType.ENDER_DRAGON.create(end);
        context.assertTrue(dragon != null, "Dragon unavailable");
        dragon.refreshPositionAfterTeleport(0, 120, 0);
        dragon.setAiDisabled(true); context.assertTrue(end.spawnEntity(dragon), "Dragon spawn failed");
        context.runAtTick(35, () -> {
            context.assertTrue(dragon.getMaxHealth() == 400, "Dragon must have 400 maximum health, got " + dragon.getMaxHealth() + " in " + end.getRegistryKey() + " alive=" + dragon.isAlive());
            context.assertTrue(dragon.getHealth() == 400, "Fresh dragon must start at full health");
            for (var entity : end.iterateEntities()) if (entity instanceof net.minecraft.entity.decoration.EndCrystalEntity) entity.discard();
            dragon.setHealth(101);
        });
        context.runAtTick(65, () -> {
            context.assertTrue(!rageState(dragon.getUuid()), "Rage must not start above 25 percent");
            dragon.setHealth(100);
        });
        // Hold the boundary stable while excluding vanilla crystal healing from this threshold test.
        for (int tick = 66; tick < 95; tick++) context.runAtTick(tick, () -> {
            dragon.connectedCrystal = null;
            dragon.age = 1;
            dragon.setHealth(100);
        });
        context.runAtTick(95, () -> {
            context.assertTrue(rageState(dragon.getUuid()), "Rage must start at exactly 25 percent, health=" + dragon.getHealth() + " age=" + dragon.age);
            dragon.discard(); end.setChunkForced(0, 0, false); context.complete();
        });
    }
    private boolean rageState(UUID dragon) {
        try {
            var field = DragonFuryMod.class.getDeclaredField("fights"); field.setAccessible(true);
            var fight = ((java.util.Map<?, ?>) field.get(DragonFuryMod.INSTANCE)).get(dragon);
            var rage = fight.getClass().getDeclaredField("rage"); rage.setAccessible(true);
            return rage.getBoolean(fight);
        } catch (ReflectiveOperationException e) { throw new RuntimeException(e); }
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE)
    public void hopperCannotCollectEgg(TestContext context) {
        ItemEntity item = context.spawnItem(Items.DRAGON_EGG, new BlockPos(1, 2, 1));
        var inventory = new net.minecraft.inventory.SimpleInventory(5);
        boolean extracted = net.minecraft.block.entity.HopperBlockEntity.extract(inventory, item);
        context.assertTrue(!extracted && item.isAlive(), "Hopper must not extract the egg");
        context.assertTrue(inventory.isEmpty(), "Hopper inventory must stay empty");
        item.discard(); context.complete();
    }
}
