from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path(__file__).resolve().parents[1]
cache=Path('/workspace/.dragonfury-fabric')
api=json.loads((cache/'fabric-api-primary.json').read_text())
mod=root/'build/libs/dragonfury-fabric-1.21.1-1.0.2.jar'
with zipfile.ZipFile(mod) as z:
 assert z.testzip() is None
 meta=json.loads(z.read('fabric.mod.json'))
 assert meta['id']=='dragonfury' and meta['depends']['minecraft']=='1.21.1'
 assert not any('GameTests' in n or 'ClientMixinCheck' in n for n in z.namelist())
 assert int.from_bytes(z.read('de/lenlive/dragonfury/DragonFuryMod.class')[6:8],'big')==65
index={
 'formatVersion':1,'game':'minecraft','versionId':'1.0.2',
 'name':'DragonFury','summary':'Stärkerer Enderdrache und Drachenei mit fünf Schlägen – Minecraft 1.21.1 Fabric.',
 'dependencies':{'minecraft':'1.21.1','fabric-loader':'0.16.14'},
 'files':[{'path':'mods/'+api['filename'],'hashes':{'sha1':api['hashes']['sha1'],'sha512':api['hashes']['sha512']},
 'env':{'client':'required','server':'required'},'downloads':[api['url']],'fileSize':api['size']}]
}
assert all(x.get('loader',{}).get('version')!='' for x in json.loads((cache/'loaders.json').read_text()))
assert any(x['loader']['version']=='0.16.14' for x in json.loads((cache/'loaders.json').read_text()))
out=root.parent/'downloads'
pack=out/'DragonFury-1.0.2-mc1.21.1.mrpack'
with zipfile.ZipFile(pack,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('modrinth.index.json',json.dumps(index,ensure_ascii=False,indent=2))
 z.write(mod,'overrides/mods/'+mod.name)
 z.write(root/'README.md','overrides/DragonFury-README.md')
with zipfile.ZipFile(pack) as z:
 assert z.testzip() is None
 assert json.loads(z.read('modrinth.index.json'))==index
 assert hashlib.sha512(z.read('overrides/mods/'+mod.name)).digest()==hashlib.sha512(mod.read_bytes()).digest()
 assert all(not n.startswith('/') and '..' not in Path(n).parts for n in z.namelist())
shutil.copyfile(mod,out/mod.name)
with zipfile.ZipFile(out/'DragonFury-Fabric-1.0.2-source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(root.rglob('*')):
  if p.is_file() and not set(p.relative_to(root).parts).intersection({'.gradle','build','run'}):
   z.write(p,Path('DragonFuryFabric')/p.relative_to(root))
print('MRPACK and mod JAR verified:',pack)
print('SHA256:',hashlib.sha256(pack.read_bytes()).hexdigest())
