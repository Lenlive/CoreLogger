package de.lenlive.dragonfury;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.entity.*;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.decoration.DisplayEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.*;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.DustParticleEffect;
import org.joml.Vector3f;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.*;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.util.hit.*;
import net.minecraft.util.math.*;
import net.minecraft.world.World;
import com.google.gson.*;
import java.nio.file.*;
import java.util.*;

public final class DragonFuryMod implements ModInitializer {
    public static DragonFuryMod INSTANCE;
    private final Map<UUID, Fight> fights = new HashMap<>();
    private final Map<String, Egg> eggs = new HashMap<>();
    private final Map<UUID, Integer> lastHit = new HashMap<>();
    private final List<Attack> attacks = new ArrayList<>();
    private record Celebration(ServerWorld world, Vec3d base, int start) {}
    private final List<Celebration> celebrations = new ArrayList<>();
    private int ticks;
    private Config config = new Config();
    static final class Config {
        double health = 400, rageFraction = .25, rageDamageMultiplier = 1.5;
        int normalCooldownSeconds = 18, rageCooldownSeconds = 10;
        double lightningDamage = 8, meteorDamage = 10;
    }
    private static final class Fight { int cooldown = 18; boolean rage, lightning = true; }
    private record Attack(EnderDragonEntity dragon, List<Vec3d> marks, boolean lightning, double scale, int starts, int duration) {}
    private static final class Egg {
        ServerWorld world; ItemEntity item;
        DisplayEntity.BlockDisplayEntity display;
        ServerBossBar bar;
        EggProgress progress = new EggProgress();
        String key;
        UUID solePlayer;
        Vec3d center() { return item.getPos(); }
    }

    @Override public void onInitialize() {
        INSTANCE = this;
        Path path = FabricLoader.getInstance().getConfigDir().resolve("dragonfury.json");
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            if (Files.exists(path)) config = gson.fromJson(Files.readString(path), Config.class);
            else Files.writeString(path, gson.toJson(config));
            if (config == null) throw new IllegalArgumentException("Empty configuration");
            config.health = finite(config.health, 400, 200, 2000);
            config.rageFraction = finite(config.rageFraction, .25, .1, .9);
            config.rageDamageMultiplier = finite(config.rageDamageMultiplier, 1.5, 1, 3);
            config.lightningDamage = finite(config.lightningDamage, 8, 0, 40);
            config.meteorDamage = finite(config.meteorDamage, 10, 0, 40);
            config.normalCooldownSeconds = Math.clamp(config.normalCooldownSeconds, 5, 300);
            config.rageCooldownSeconds = Math.clamp(config.rageCooldownSeconds, 5, 300);
        } catch (Exception e) { throw new IllegalStateException("Cannot load dragonfury.json", e); }
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof EnderDragonEntity dragon && world.getRegistryKey().equals(World.END)) prepare(dragon);
        });
        ServerTickEvents.END_SERVER_TICK.register(this::tick);
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            eggs.values().forEach(this::removeVisuals); eggs.clear(); fights.clear(); attacks.clear(); lastHit.clear(); celebrations.clear(); ticks = 0;
        });
    }

    private static double finite(double value, double fallback, double min, double max) {
        return Double.isFinite(value) ? Math.clamp(value, min, max) : fallback;
    }
    private Fight prepare(EnderDragonEntity dragon) {
        return fights.computeIfAbsent(dragon.getUuid(), id -> {
            double ratio = dragon.getHealth() / dragon.getMaxHealth();
            dragon.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(config.health);
            dragon.setHealth((float) Math.max(1, ratio * dragon.getMaxHealth()));
            Fight result = new Fight(); result.cooldown = config.normalCooldownSeconds; return result;
        });
    }
    private boolean eligible(PlayerEntity p) { return !p.isSpectator() && !p.isCreative() && p.isAlive(); }
    private boolean counts(PlayerEntity p) { return !p.isSpectator() && p.isAlive(); }
    private List<ServerPlayerEntity> nearby(Egg e) {
        return e.world.getPlayers(p -> counts(p) && horizontalSquared(p.getPos(), e.center()) <= 25);
    }
    private List<ServerPlayerEntity> targets(EnderDragonEntity dragon) {
        return ((ServerWorld) dragon.getWorld()).getPlayers(p -> eligible(p) && p.squaredDistanceTo(dragon) <= 96 * 96);
    }
    private void tick(MinecraftServer server) {
        ticks++;
        if (ticks % 20 == 0) {
            Set<UUID> seen = new HashSet<>();
            for (ServerWorld world : server.getWorlds()) {
                for (Entity entity : world.iterateEntities()) {
                    if (entity.getCommandTags().contains("dragonfury_visual") && eggs.values().stream().noneMatch(e -> e.display == entity)) entity.discard();
                    if (entity instanceof ItemEntity item && item.getStack().isOf(Items.DRAGON_EGG)) {
                        item.setNoGravity(true); item.setVelocity(Vec3d.ZERO); item.setNeverDespawn();
                        String key = world.getRegistryKey().getValue() + ":item:" + item.getUuid();
                        if (!eggs.containsKey(key)) {
                            Egg e = new Egg(); e.world = world; e.item = item; e.key = key; createVisuals(e); eggs.put(key, e);
                        }
                    }
                    if (!(entity instanceof EnderDragonEntity dragon) || !dragon.isAlive() || !world.getRegistryKey().equals(World.END)) continue;
                    seen.add(dragon.getUuid());
                    Fight f = prepare(dragon);
                    List<ServerPlayerEntity> players = targets(dragon);
                    if (!f.rage && dragon.getHealth() <= dragon.getMaxHealth() * config.rageFraction) {
                        f.rage = true; f.cooldown = Math.min(f.cooldown, config.rageCooldownSeconds);
                        players.forEach(p -> p.sendMessage(Text.literal("§5§lDer Enderdrache gerät in Raserei!"), false));
                    }
                    if (players.isEmpty() || --f.cooldown > 0) continue;
                    List<Vec3d> marks = players.stream().limit(8).map(Entity::getPos).toList();
                    players.forEach(p -> p.sendMessage(Text.literal(f.lightning ? "§dDrachenblitze! Verlasse die violetten Markierungen!" : "§6Meteore! Verlasse die Einschlagstellen!"), false));
                    attacks.add(new Attack(dragon, marks, f.lightning, f.rage ? config.rageDamageMultiplier : 1, ticks, f.lightning ? 60 : 80));
                    f.lightning = !f.lightning; f.cooldown = f.rage ? config.rageCooldownSeconds : config.normalCooldownSeconds;
                }

            }
            fights.keySet().retainAll(seen);
            lastHit.keySet().removeIf(id -> server.getPlayerManager().getPlayer(id) == null);
        }
        tickAttacks();
        tickEggs();
        updateBossBarViewers(server);
        celebrations.removeIf(c -> {
            int age = ticks - c.start;
            if (age >= 40) return true;
            for (int arm = 0; arm < 2; arm++) {
                double angle = age * .35 + arm * Math.PI;
                Vec3d p = c.base.add(Math.cos(angle), age / 20.0, Math.sin(angle));
                c.world.spawnParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0, 0, 0, 0);
                c.world.spawnParticles(ParticleTypes.DRAGON_BREATH, p.x, p.y, p.z, 2, 0, 0, 0, 0);
            }
            return false;
        });
    }
    private void ring(ServerWorld world, Vec3d center, double radius) {
        for (int i = 0; i < 32; i++) {
            double angle = 2 * Math.PI * i / 32;
            world.spawnParticles(ParticleTypes.DRAGON_BREATH, center.x + Math.cos(angle) * radius, center.y + .1, center.z + Math.sin(angle) * radius, 1, 0, 0, 0, 0);
        }
    }
    private void tickAttacks() {
        Iterator<Attack> it = attacks.iterator();
        while (it.hasNext()) {
            Attack a = it.next();
            if (!a.dragon.isAlive() || a.dragon.isRemoved()) { it.remove(); continue; }
            ServerWorld world = (ServerWorld) a.dragon.getWorld();
            int age = ticks - a.starts;
            double radius = a.lightning ? 3 : 4;
            if (age % 5 == 0) for (Vec3d mark : a.marks) {
                ring(world, mark, radius);
                if (!a.lightning) {
                    double y = mark.y + 24 * (1 - Math.min(1, (double) age / a.duration));
                    world.spawnParticles(ParticleTypes.FLAME, mark.x, y, mark.z, 12, .3, .3, .3, .02);
                    world.spawnParticles(ParticleTypes.SMOKE, mark.x, y, mark.z, 5, .2, .2, .2, .01);
                }
            }
            if (age < a.duration) continue;
            for (Vec3d mark : a.marks) {
                // Lightning is a cosmetic bolt only: it cannot ignite blocks or inflict duplicate damage.
                if (a.lightning) {
                    LightningEntity bolt = EntityType.LIGHTNING_BOLT.create(world);
                    if (bolt != null) { bolt.refreshPositionAfterTeleport(mark); bolt.setCosmetic(true); world.spawnEntity(bolt); }
                } else {
                    world.spawnParticles(ParticleTypes.EXPLOSION, mark.x, mark.y, mark.z, 1, 0, 0, 0, 0);
                    world.playSound(null, BlockPos.ofFloored(mark), SoundEvents.ENTITY_GENERIC_EXPLODE.value(), SoundCategory.HOSTILE, 1, .7f);
                }
            }
            for (ServerPlayerEntity p : world.getPlayers()) if (eligible(p) && a.marks.stream().anyMatch(m -> p.getPos().squaredDistanceTo(m) <= radius * radius))
                p.damage(world.getDamageSources().mobAttack(a.dragon), (float) ((a.lightning ? config.lightningDamage : config.meteorDamage) * a.scale));
            it.remove();
        }
    }
    private void createVisuals(Egg e) {
        e.display = EntityType.BLOCK_DISPLAY.create(e.world);
        e.bar = new ServerBossBar(Text.literal("Drachenei"), BossBar.Color.PURPLE, BossBar.Style.PROGRESS);
        if (e.display == null) throw new IllegalStateException("Display entity unavailable");
        NbtCompound data = e.display.writeNbt(new NbtCompound());
        NbtCompound block = new NbtCompound(); block.putString("Name", "minecraft:dragon_egg");
        data.put("block_state", block); data.putBoolean("Glowing", true); data.putInt("glow_color_override", 0xAA00AA);
        data.putString("billboard", "fixed");
        data.putInt("teleport_duration", 5);
        NbtCompound transformation = new NbtCompound();
        transformation.put("scale", floats(.65f, .65f, .65f));
        transformation.put("translation", floats(-.325f, 0, -.325f));
        transformation.put("left_rotation", floats(0, 0, 0, 1));
        transformation.put("right_rotation", floats(0, 0, 0, 1));
        data.put("transformation", transformation);
        e.display.readNbt(data);
        String source = "item:" + e.item.getUuid();
        e.display.setCustomName(Text.literal("dragonfury:" + source));
        e.display.setCustomNameVisible(false);
        e.display.addCommandTag("dragonfury_visual");
        e.display.refreshPositionAfterTeleport(e.center().add(0, .7, 0));
        e.world.spawnEntity(e.display);
        updateLabel(e, 0);
    }
    private static NbtList floats(float... values) {
        NbtList list = new NbtList();
        for (float value : values) list.add(NbtFloat.of(value));
        return list;
    }
    private void updateLabel(Egg e, int count) {
        boolean open = count == 1;
        e.bar.setName(Text.literal("Drachenei • 5 Blöcke • " + count + " Spieler " + (open ? "✔" : "✖") + " • " + e.progress.hits() + "/5"));
        e.bar.setPercent(e.progress.hits() / 5f);
        e.bar.setColor(open ? BossBar.Color.GREEN : BossBar.Color.RED);
    }
    private void updateBossBarViewers(MinecraftServer server) {
        Map<ServerPlayerEntity, Egg> selected = new HashMap<>();
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (!counts(player)) continue;
            Egg closest = null;
            double distance = 16 * 16;
            for (Egg e : eggs.values()) {
                if (e.world != player.getServerWorld()) continue;
                double candidate = horizontalSquared(player.getPos(), e.center());
                if (candidate < distance) { closest = e; distance = candidate; }
            }
            if (closest != null) selected.put(player, closest);
        }
        for (Egg e : eggs.values()) {
            for (ServerPlayerEntity viewer : new ArrayList<>(e.bar.getPlayers()))
                if (selected.get(viewer) != e) e.bar.removePlayer(viewer);
            for (var entry : selected.entrySet())
                if (entry.getValue() == e) e.bar.addPlayer(entry.getKey());
        }
    }
    private static double horizontalSquared(Vec3d a, Vec3d b) {
        double dx = a.x - b.x, dz = a.z - b.z;
        return dx * dx + dz * dz;
    }
    private void showBoundary(Egg e, int count) {
        List<ServerPlayerEntity> viewers = e.world.getPlayers(p -> horizontalSquared(p.getPos(), e.center()) <= 16 * 16);
        if (viewers.isEmpty()) return;
        Vector3f color = count == 1 ? new Vector3f(.15f, 1, .2f) : new Vector3f(1, .15f, .15f);
        DustParticleEffect dust = new DustParticleEffect(color, 1.25f);
        Vec3d center = e.center();
        for (int i = 0; i < 64; i++) {
            double angle = i * Math.PI * 2 / 64;
            double x = center.x + Math.cos(angle) * 5, z = center.z + Math.sin(angle) * 5;
            if (!e.world.isChunkLoaded(BlockPos.ofFloored(x, center.y, z))) continue;
            Vec3d from = new Vec3d(x, center.y + 3, z), to = new Vec3d(x, center.y - 12, z);
            BlockHitResult ground = e.world.raycast(new net.minecraft.world.RaycastContext(from, to,
                net.minecraft.world.RaycastContext.ShapeType.COLLIDER, net.minecraft.world.RaycastContext.FluidHandling.NONE, e.display));
            double y = ground.getType() == HitResult.Type.MISS ? center.y - .4 : ground.getPos().y + .08;
            for (ServerPlayerEntity viewer : viewers)
                e.world.spawnParticles(viewer, dust, true, x, y, z, 1, 0, 0, 0, 0);
        }
    }
    private boolean exists(Egg e) {
        return e.item.isAlive() && !e.item.isRemoved();
    }
    private void tickEggs() {
        Iterator<Egg> it = eggs.values().iterator();
        while (it.hasNext()) {
            Egg e = it.next();
            if (!exists(e)) { removeVisuals(e); it.remove(); continue; }
            List<ServerPlayerEntity> players = nearby(e);
            UUID sole = players.size() == 1 ? players.getFirst().getUuid() : null;
            if (!Objects.equals(sole, e.solePlayer)) e.progress.reset();
            e.solePlayer = sole;
            updateLabel(e, players.size());
            if (ticks % 10 == 0) showBoundary(e, players.size());
            if (ticks % 5 == 0) {
                Vec3d position = e.center().add(0, .7 + Math.sin(ticks * .05) * .12, 0);
                e.display.refreshPositionAndAngles(position.x, position.y, position.z, (ticks * 2) % 360, 0);
            }
        }
    }
    private void removeVisuals(Egg e) { e.display.discard(); e.bar.clearPlayers(); }
    public void swing(ServerPlayerEntity player) {
        if (!counts(player)) return;
        Vec3d eye = player.getEyePos(), direction = player.getRotationVec(1);
        HitResult wall = player.raycast(4.5, 1, false);
        double nearest = wall.getType() == HitResult.Type.MISS ? 4.5 : eye.distanceTo(wall.getPos()) + .02;
        Egg selected = null;
        for (Egg e : eggs.values()) {
            if (e.world != player.getServerWorld()) continue;
            Vec3d offset = e.display.getPos().subtract(eye);
            double along = offset.dotProduct(direction);
            if (along < 0 || along > nearest || offset.lengthSquared() - along * along > .55 * .55) continue;
            selected = e; nearest = along;
        }
        if (selected != null) hit(player, selected);
    }
    private void hit(ServerPlayerEntity player, Egg e) {
        if (!exists(e) || !counts(player) || player.getPos().squaredDistanceTo(e.center()) > 25) return;
        if (ticks - lastHit.getOrDefault(player.getUuid(), ticks - 6) < 6) return;
        lastHit.put(player.getUuid(), ticks);
        List<ServerPlayerEntity> players = nearby(e);
        if (players.size() != 1 || players.getFirst() != player) {
            e.progress.reset(); player.sendMessage(Text.literal("§cDu musst allein im Umkreis von 5 Blöcken um das Ei sein!"), true); return;
        }
        if (e.progress.hits() == 4 && player.getInventory().getEmptySlot() < 0) {
            player.sendMessage(Text.literal("§cDu brauchst einen freien Inventarplatz!"), true); return;
        }
        if (!Objects.equals(e.solePlayer, player.getUuid())) e.progress.reset();
        e.solePlayer = player.getUuid();
        boolean complete = e.progress.hit(player.getUuid(), true);
        e.world.playSound(null, BlockPos.ofFloored(e.center()), SoundEvents.BLOCK_AMETHYST_BLOCK_HIT, SoundCategory.PLAYERS, 1, 1 + e.progress.hits() * .1f);
        e.world.spawnParticles(ParticleTypes.DRAGON_BREATH, e.center().x, e.center().y, e.center().z, 20, .4, .5, .4, .02);
        updateLabel(e, 1);
        if (!complete) return;
        ItemStack reward = e.item.getStack().copyWithCount(1);
        if (!player.getInventory().insertStack(reward)) {
            e.progress.reset(); return;
        }
        if (e.item.getStack().getCount() > 1) {
            e.item.getStack().decrement(1);
            e.progress.reset();
            updateLabel(e, 1);
        } else e.item.discard();
        if (e.item.isRemoved()) { eggs.remove(e.key); removeVisuals(e); }
        e.world.playSound(null, player.getBlockPos(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.PLAYERS, 1, .8f);
        celebrations.add(new Celebration(e.world, player.getPos(), ticks));
    }
}
