# DragonFury – Fabric-Modpack

Minecraft **1.21.1**, Fabric Loader **0.16.14**, Fabric API **0.116.17+1.21.1**, Java **21 oder neuer**.

## Einfach importieren

`DragonFury-1.0.1-mc1.21.1.mrpack` herunterladen und in die Modrinth-App ziehen. Alternativ in der App eine Instanz aus Datei importieren. Der Import installiert Fabric, die Fabric API und DragonFury. Anschließend die Instanz starten und eine neue Einzelspielerwelt öffnen oder einen passenden Fabric-Server betreten.

Dies ist eine echte Fabric-Mod, keine umbenannte Paper-JAR. Die Paper-Ausgabe für 26.3 bleibt unabhängig. Minecraft-Welten aus 26.3 dürfen nicht mit 1.21.1 geöffnet werden.

## Multiplayer und NoRisk

Für die Regeln im Multiplayer muss **der Server ebenfalls Minecraft 1.21.1 mit Fabric, Fabric API und der DragonFury-Fabric-JAR** verwenden. Ein reines Client-Modpack kann die Regeln auf einem fremden Server nicht aktivieren. Paper-Plugins funktionieren auf einem Fabric-Server nicht.

Das `.mrpack`-Paket ist für den Modrinth-Import vorgesehen. Kompatibilität und Import in NoRisk wurden nicht geprüft; kein zugesicherter NoRisk-Import.

## Funktionen

- 400 Lebenspunkte. Bei vorhandenen Drachen wird beim ersten Erfassen der prozentuale Lebensstand erhalten.
- Drachenblitze: violette Zielkreise, drei Sekunden Vorwarnung, acht Schadenspunkte, drei Blöcke Radius.
- Meteore: fallende Feuer-/Rauchpartikel, vier Sekunden Vorwarnung, zehn Schadenspunkte, vier Blöcke Radius. Keine Blockschäden oder Brände durch die zusätzlichen Fähigkeiten.
- Wutphase ab 25 % Leben (100 von 400): Fähigkeiten alle zehn statt achtzehn Sekunden und 1,5-facher Fähigkeitsschaden. Für den laufenden Kampf bleibt die Wutphase aktiv; nach einem Neustart wird sie anhand des Lebensstands neu bestimmt.
- Normaler Drachenatem und Kristallheilung bleiben. Keine Schockwelle, keine beschworenen Endermänner.
- Spezialangriffe betreffen lebende Überlebens-/Abenteuerspieler, höchstens acht Zielpositionen. Überlappende Kreise verursachen pro Angriff nur einmal Schaden.
- Nur fallengelassene Ei-Items bekommen die Spezialmechanik. Platzierte Ei-Blöcke bleiben vollständig normal: keine zusätzliche Anzeige, keine Schlagregel und keine Blockrender-Änderung.
- Jeder Drop erhält genau eine kleinere, echte 3D-Ei-Anzeige mit violetter Umrandung. Sie schwebt auf/ab und rotiert langsam um die eigene Achse; sie richtet sich nicht zur Kamera aus. Der ursprüngliche Item-Render wird im Client nur solange ausgeblendet, wie seine Ersatzanzeige geladen ist.
- Spieleranzahl, Freigabe und `0/5` bis `5/5` stehen ausschließlich in einer Bossleiste. Grün bei einem Spieler, Rot sonst. Pro Spieler wird nur die Leiste des nächsten Eis innerhalb von 16 Blöcken horizontalem Abstand gezeigt; sie verschwindet beim Entfernen des Drops oder Verlassen des Bereichs.
- Ein sichtbarer roter/grüner Partikelkreis markiert am Boden den 5-Block-Radius. Die Partikel werden mit erhöhter Sichtweite gesendet. Auf unebenem Boden wird der Kreis auf die Oberfläche projiziert.
- Der Sperrbereich ist ein horizontaler Kreis einschließlich der 5-Block-Grenze, ohne zusätzliche Höhenbegrenzung: Auch Spieler weit über oder unter dem Ei zählen. Lebende Kreativspieler zählen, Zuschauer nicht. Auch Wände verhindern das Zählen nicht.
- Fünf echte Schläge bei mindestens sechs Ticks Abstand; nur der einzige Spieler im Kreis kann Fortschritt erzielen. Ein zweiter Spieler oder Spielerwechsel setzt den Fortschritt zurück. Zum Schlagen muss das sichtbare Ei innerhalb normaler Reichweite und Sichtlinie liegen; es kann nicht aus beliebiger Höhe eingesammelt werden.
- Der fünfte Schlag gibt genau ein Ei direkt ins Inventar, sofern Platz vorhanden ist. Bei einem Stack bleiben die übrigen Eier als Drop erhalten und benötigen ihre eigene Schlagfolge. Erfolgseffekt: zweisekündige violett-weiße Doppelspirale und Sound.
- Keine passive Aufnahme und keine Trichteraufnahme von Ei-Drops. Bossleisten und Fortschritt werden nach Neustarts neu aufgebaut; alte Anzeigen der früheren Version werden beim Laden bereinigt.

Die Anzeige nutzt Vanilla-Display-Entities. Schrift und Eiform können ohne spezielles Ressourcenpaket vom Beispielbild abweichen.

## Konfiguration

`config/dragonfury.json` wird beim ersten Start erstellt. Lebenspunkte, Wutschwelle, Fähigkeitsschaden und Abklingzeiten können dort geändert werden. Danach die Einzelspielerwelt bzw. den Server vollständig neu starten.

## Entwicklung und Tests

Gradle 9.2.1 und JDK 25 werden für den getesteten Build verwendet; das Ergebnis verwendet Java-21-Bytecode. Der Build lädt Minecraft und Fabric von ihren offiziellen Quellen und Maven-Abhängigkeiten aus den konfigurierten Repositories.

```sh
gradle build
```

Der Build führt Minecraft-GameTests aus. Diese verwenden eine separate Testwelt unter `build/run/gameTest`. Sie wird nicht als Spielstand mitgeliefert. Der Testmod und seine Hilfsspieler sind nicht Bestandteil der veröffentlichten Mod.

Build und acht erforderliche Minecraft-GameTests bestanden: fünf Schläge auf den schwebenden Drop bis zur Vergabe, Sperre durch einen zweiten Spieler 200 Blöcke höher, normales Verhalten platzierter Ei-Blöcke, Aufnahmeschutz, Trichterschutz, Schlagfolge/Spielerwechsel, Drachen-Lebenspunkte/Wutgrenze sowie Bossleiste/Rotation/Leistenentfernung. Der Grenzwerttest wartet auf die aktive End-Entität und kontrolliert Kristallheilung für einen stabilen Lebensstand.

Zusätzlich wurde der Item-Renderer im echten Fabric-Client-Kontext geladen und die Client-Mixin-Injektion erfolgreich validiert (`runClientMixinCheck`). Dies ist ein Ladetest ohne grafisches Fenster, kein visueller Spieltest.

## Update von 1.0.0

Minecraft vollständig schließen und die alte DragonFury-JAR im `mods`-Ordner durch `dragonfury-fabric-1.21.1-1.0.1.jar` ersetzen. Nicht zwei Versionen gleichzeitig installieren. Fabric API bleibt erforderlich. Im Multiplayer Server und Clients aktualisieren, damit die doppelte Darstellung auch auf den Clients verschwindet. Die `.mrpack` lässt sich alternativ als neue Modrinth-Instanz importieren; bestehende Spielstände werden dabei nicht automatisch übernommen.

Ein visueller Test im Minecraft-Client oder NoRisk-Launcher wurde nicht durchgeführt. Einen vorhandenen produktiven Server zunächst sichern und die Mod in einer Testwelt ausprobieren.
