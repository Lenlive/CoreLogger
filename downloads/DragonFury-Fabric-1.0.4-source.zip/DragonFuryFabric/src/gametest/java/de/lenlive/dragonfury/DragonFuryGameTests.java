package de.lenlive.dragonfury;

import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.GameTest;
import net.minecraft.test.TestContext;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.UUID;

public class DragonFuryGameTests implements FabricGameTest {
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE)
    public void progressRules(TestContext context) {
        EggProgress p = new EggProgress(); UUID a = UUID.randomUUID(), b = UUID.randomUUID();
        for (int i = 0; i < 4; i++) context.assertTrue(!p.hit(a, true), "Must not reward before fifth hit");
        context.assertTrue(p.hit(a, true), "Fifth hit must reward"); p.reset();
        p.hit(a, true); p.hit(a, true); p.hit(b, true);
        context.assertTrue(p.hits() == 1, "Player cannot inherit another player's hits");
        context.assertTrue(!p.hit(b, false) && p.hits() == 0, "Contested hit must reset");
        context.complete();
    }
    private ItemEntity floatingEgg(TestContext context) {
        ItemEntity item = context.spawnItem(Items.DRAGON_EGG, new BlockPos(1, 2, 1));
        item.setNoGravity(true); item.setVelocity(Vec3d.ZERO); return item;
    }
    private void strike(ServerPlayerEntity player, ItemEntity item) {
        player.lookAt(net.minecraft.command.argument.EntityAnchorArgumentType.EntityAnchor.EYES, item.getPos().add(0, 1.5, 0));
        DragonFuryMod.INSTANCE.swing(player);
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 130)
    public void fiveHitsCollectDroppedEgg(TestContext context) {
        ItemEntity item = floatingEgg(context);
        ServerPlayerEntity player = context.createMockCreativeServerPlayerInWorld();
        player.refreshPositionAfterTeleport(item.getPos().add(2, 0, 0));
        for (int i = 0; i < 5; i++) {
            final int step = i;
            context.runAtTick(30 + 8 * i, () -> {
                strike(player, item);
                if (step < 4) context.assertTrue(item.isAlive(), "Dropped egg disappeared early");
            });
        }
        context.runAtTick(80, () -> {
            context.assertTrue(item.isRemoved(), "Dropped egg not collected after five swings");
            context.assertTrue(player.getInventory().count(Items.DRAGON_EGG) == 1, "Must give exactly one egg");
            player.discard(); context.complete();
        });
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 130)
    public void otherPlayerBlocksCollection(TestContext context) {
        ItemEntity item = floatingEgg(context);
        ServerPlayerEntity a = context.createMockCreativeServerPlayerInWorld();
        ServerPlayerEntity b = context.createMockCreativeServerPlayerInWorld();
        a.refreshPositionAfterTeleport(item.getPos().add(2, 0, 0));
        b.refreshPositionAfterTeleport(item.getPos().add(-1, 200, 0));
        for (int i = 0; i < 5; i++) context.runAtTick(30 + 8 * i, () -> strike(a, item));
        context.runAtTick(80, () -> {
            context.assertTrue(item.isAlive(), "Contested dropped egg must remain");
            context.assertTrue(a.getInventory().count(Items.DRAGON_EGG) == 0, "No contested reward");
            a.discard(); b.discard(); item.discard(); context.complete();
        });
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 100)
    public void placedEggStaysNormal(TestContext context) {
        BlockPos relative = new BlockPos(1, 2, 1);
        context.setBlockState(new BlockPos(1, 1, 1), Blocks.STONE);
        context.setBlockState(relative, Blocks.DRAGON_EGG);
        BlockPos pos = context.getAbsolutePos(relative);
        ServerPlayerEntity player = context.createMockCreativeServerPlayerInWorld();
        player.refreshPositionAfterTeleport(Vec3d.ofCenter(pos).add(2, 0, 0));
        context.runAtTick(30, () -> {
            context.assertTrue(context.getWorld().getEntitiesByClass(net.minecraft.entity.decoration.DisplayEntity.BlockDisplayEntity.class,
                new net.minecraft.util.math.Box(pos).expand(3), e -> true).isEmpty(), "Placed blocks must not gain a floating copy");
            context.assertTrue(player.interactionManager.tryBreakBlock(pos), "Normal creative block break must work");
            context.assertTrue(context.getWorld().getBlockState(pos).isAir(), "Placed egg must not require five hits");
            player.discard(); context.complete();
        });
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 100)
    public void passivePickupBlocked(TestContext context) {
        ServerPlayerEntity player = context.createMockCreativeServerPlayerInWorld();
        ItemEntity item = context.spawnItem(Items.DRAGON_EGG, new BlockPos(1, 2, 1));
        item.resetPickupDelay(); player.refreshPositionAfterTeleport(item.getPos());
        context.runAtTick(30, () -> {
            item.onPlayerCollision(player);
            context.assertTrue(item.isAlive() && !item.isRemoved(), "Passive pickup bypassed five hits");
            context.assertTrue(player.getInventory().count(Items.DRAGON_EGG) == 0, "Passive pickup gave egg");
            item.discard(); player.discard(); context.complete();
        });
    }

    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 300)
    public void dragonHealthAndRageBoundary(TestContext context) {
        var end = context.getWorld().getServer().getWorld(net.minecraft.world.World.END);
        context.assertTrue(end != null, "End dimension unavailable");
        end.setChunkForced(0, 0, true);
        end.getChunk(0, 0);
        var dragon = EntityType.ENDER_DRAGON.create(end);
        context.assertTrue(dragon != null, "Dragon unavailable");
        dragon.refreshPositionAfterTeleport(0, 120, 0);
        dragon.setAiDisabled(true); context.assertTrue(end.spawnEntity(dragon), "Dragon spawn failed");
        int[] stage = {0}; long[] readyAt = {0};
        context.addInstantFinalTask(() -> {
            if (stage[0] == 0) {
                context.assertTrue(dragon.getMaxHealth() == 400, "Waiting for tracked dragon with 400 maximum health");
                context.assertTrue(dragon.getHealth() == 400, "Fresh dragon must start at full health");
                dragon.connectedCrystal = null; dragon.setHealth(101);
                stage[0] = 1; readyAt[0] = end.getTime() + 25;
            }
            if (stage[0] == 1) {
                context.assertTrue(end.getTime() >= readyAt[0], "Waiting for above-threshold tick");
                context.assertTrue(!rageState(dragon.getUuid()), "Rage must not start above 25 percent");
                stage[0] = 2;
            }
            dragon.connectedCrystal = null; dragon.age = 1; dragon.setHealth(100);
            context.assertTrue(rageState(dragon.getUuid()), "Waiting for rage at exactly 25 percent");
            dragon.discard(); end.setChunkForced(0, 0, false);
        });
    }

    private boolean rageState(UUID dragon) {
        try {
            var field = DragonFuryMod.class.getDeclaredField("fights"); field.setAccessible(true);
            var fight = ((java.util.Map<?, ?>) field.get(DragonFuryMod.INSTANCE)).get(dragon);
            var rage = fight.getClass().getDeclaredField("rage"); rage.setAccessible(true);
            return rage.getBoolean(fight);
        } catch (ReflectiveOperationException e) { throw new RuntimeException(e); }
    }
    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE)
    public void hopperCannotCollectEgg(TestContext context) {
        ItemEntity item = context.spawnItem(Items.DRAGON_EGG, new BlockPos(1, 2, 1));
        var inventory = new net.minecraft.inventory.SimpleInventory(5);
        boolean extracted = net.minecraft.block.entity.HopperBlockEntity.extract(inventory, item);
        context.assertTrue(!extracted && item.isAlive(), "Hopper must not extract the egg");
        context.assertTrue(inventory.isEmpty(), "Hopper inventory must stay empty");
        item.discard(); context.complete();
    }

    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 140)
    public void bossBarRotationAndUnlimitedHeight(TestContext context) {
        ItemEntity item = floatingEgg(context);
        ServerPlayerEntity a = context.createMockCreativeServerPlayerInWorld();
        ServerPlayerEntity b = context.createMockCreativeServerPlayerInWorld();
        a.refreshPositionAfterTeleport(item.getPos().add(2, 0, 0));
        b.refreshPositionAfterTeleport(item.getPos().add(1, 200, 0));
        float[] firstYaw = {0};
        context.runAtTick(30, () -> {
            var bar = eggBar(item);
            context.assertTrue(bar.getName().getString().contains("2 Spieler"), "Players above the egg must count");
            context.assertTrue(bar.getName().getString().contains("0/5"), "Contested hit must not count");
            context.assertTrue(bar.getPlayers().contains(a) && bar.getPlayers().contains(b), "Both heights must see boss bar");
            context.assertTrue(bar.getColor() == net.minecraft.entity.boss.BossBar.Color.RED, "Contested bar must be red");
            var display = eggDisplay(context, item); firstYaw[0] = display.getYaw();
            var nbt = display.writeNbt(new net.minecraft.nbt.NbtCompound());
            context.assertTrue(nbt.getCompound("transformation").getList("scale", 5).getFloat(0) == 1.6f, "Egg must use moderate 1.6 scale");
            context.assertTrue(display.writeNbt(new net.minecraft.nbt.NbtCompound()).getString("billboard").equals("fixed"), "Egg must not face camera");
            var labels = context.getWorld().getEntitiesByClass(net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.class,
                item.getBoundingBox().expand(5), e -> true);
            context.assertTrue(labels.size() == 1 && labels.getFirst().getY() > display.getY() + 1.6,
                "Text must stay above the larger egg");
            context.assertTrue(context.getWorld().getEntitiesByClass(net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.class,
                item.getBoundingBox().expand(5), e -> true).size() == 1, "Exactly one floating label must remain");
            b.refreshPositionAfterTeleport(item.getPos().add(100, 200, 0));
        });
        context.runAtTick(45, () -> {
            var bar = eggBar(item);
            context.assertTrue(bar.getName().getString().contains("1 Spieler"), "Horizontal radius must ignore height");
            context.assertTrue(bar.getColor() == net.minecraft.entity.boss.BossBar.Color.GREEN, "Solo bar must be green");
            context.assertTrue(eggDisplay(context, item).getYaw() != firstYaw[0], "Floating egg must rotate");
            a.refreshPositionAfterTeleport(item.getPos().add(5.1, 0, 0));
        });
        context.runAtTick(55, () -> {
            context.assertTrue(eggBar(item).getPlayers().isEmpty(), "Bar must hide immediately outside 5 blocks");
            var labels = context.getWorld().getEntitiesByClass(net.minecraft.entity.decoration.DisplayEntity.TextDisplayEntity.class,
                item.getBoundingBox().expand(5), e -> true);
            context.assertTrue(labels.size() == 1, "Floating label must remain outside boss-bar radius");
            context.assertTrue(labels.getFirst().writeNbt(new net.minecraft.nbt.NbtCompound()).getString("text").contains("0 Spieler"), "Floating label must show current player count");
            a.refreshPositionAfterTeleport(item.getPos().add(5, 200, 0));
        });
        context.runAtTick(65, () -> {
            context.assertTrue(eggBar(item).getPlayers().contains(a), "Exactly 5 horizontal blocks must include player at any height");
            context.assertTrue(eggBar(item).getName().getString().contains("1 Spieler"), "Boundary player must count");
            a.discard(); b.discard(); item.discard(); context.complete();
        });
    }
    private net.minecraft.entity.decoration.DisplayEntity.BlockDisplayEntity eggDisplay(TestContext context, ItemEntity item) {
        var displays = context.getWorld().getEntitiesByClass(net.minecraft.entity.decoration.DisplayEntity.BlockDisplayEntity.class,
                item.getBoundingBox().expand(3), e -> e.getCustomName() != null && e.getCustomName().getString().equals("dragonfury:item:" + item.getUuid()));
        context.assertTrue(displays.size() == 1, "Exactly one display per dropped item");
        return displays.getFirst();
    }
    private net.minecraft.entity.boss.ServerBossBar eggBar(ItemEntity item) {
        try {
            var eggs = DragonFuryMod.class.getDeclaredField("eggs"); eggs.setAccessible(true);
            String key = item.getWorld().getRegistryKey().getValue() + ":item:" + item.getUuid();
            Object egg = ((java.util.Map<?, ?>)eggs.get(DragonFuryMod.INSTANCE)).get(key);
            var bar = egg.getClass().getDeclaredField("bar"); bar.setAccessible(true);
            return (net.minecraft.entity.boss.ServerBossBar)bar.get(egg);
        } catch (ReflectiveOperationException e) { throw new RuntimeException(e); }
    }

    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 100)
    public void inventoryCarrierGlowLifecycle(TestContext context) {
        ServerPlayerEntity player = context.createMockCreativeServerPlayerInWorld();
        context.runAtTick(5, () -> player.getInventory().setStack(10, new net.minecraft.item.ItemStack(Items.DRAGON_EGG)));
        context.runAtTick(10, () -> {
            context.assertTrue(EggGlowNetworking.isCarrier(player.getUuid()), "Egg in inventory must enable carrier outline");
            context.assertTrue(!player.isGlowing(), "Carrier must not receive wall-penetrating vanilla glow");
            player.getInventory().setStack(10, net.minecraft.item.ItemStack.EMPTY);
        });
        context.runAtTick(15, () -> {
            context.assertTrue(!EggGlowNetworking.isCarrier(player.getUuid()), "Outline must clear after egg removal");
            player.setStackInHand(net.minecraft.util.Hand.OFF_HAND, new net.minecraft.item.ItemStack(Items.DRAGON_EGG));
        });
        context.runAtTick(20, () -> {
            context.assertTrue(EggGlowNetworking.isCarrier(player.getUuid()), "Egg in off hand must enable outline");
            player.setStackInHand(net.minecraft.util.Hand.OFF_HAND, net.minecraft.item.ItemStack.EMPTY);
        });
        context.runAtTick(25, () -> {
            context.assertTrue(!EggGlowNetworking.isCarrier(player.getUuid()), "Offhand removal must clear outline");
            player.discard(); context.complete();
        });
    }

    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE)
    public void outlineMustNotPassWalls(TestContext context) {
        var world = context.getWorld();
        Vec3d camera = Vec3d.of(context.getAbsolutePos(new BlockPos(0, 3, 3))).add(.5, .1, .5);
        BlockPos body = context.getAbsolutePos(new BlockPos(3, 2, 3));
        var bounds = new net.minecraft.util.math.Box(body.getX() + .2, body.getY() + .1, body.getZ() + .2,
            body.getX() + .8, body.getY() + 1.7, body.getZ() + .8);
        var viewer = EntityType.ARMOR_STAND.create(world);
        context.assertTrue(viewer != null, "Viewer unavailable");
        context.assertTrue(OutlineVisibility.hasClearSight(world, camera, bounds, viewer), "Unobstructed carrier must be visible");
        for (int y = 1; y <= 4; y++) for (int z = 2; z <= 4; z++) context.setBlockState(new BlockPos(2, y, z), Blocks.STONE);
        context.assertTrue(!OutlineVisibility.hasClearSight(world, camera, bounds, viewer), "Outline must not pass a solid wall");
        for (int y = 1; y <= 4; y++) for (int z = 2; z <= 4; z++) context.setBlockState(new BlockPos(2, y, z), Blocks.AIR);
        context.setBlockState(new BlockPos(2, 3, 3), Blocks.STONE);
        context.assertTrue(!OutlineVisibility.hasClearSight(world, camera, bounds, viewer), "Partly hidden body must not be outlined");
        context.complete();
    }

    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 250)
    public void meteorFireExpiresWithoutBurningBlocks(TestContext context) {
        BlockPos fire = new BlockPos(1, 2, 1);
        context.setBlockState(new BlockPos(1, 1, 1), Blocks.OAK_PLANKS);
        context.setBlockState(new BlockPos(2, 2, 1), Blocks.OAK_PLANKS);
        try {
            var impact = DragonFuryMod.class.getDeclaredMethod("leaveMeteorFire", net.minecraft.server.world.ServerWorld.class, Vec3d.class);
            impact.setAccessible(true);
            impact.invoke(DragonFuryMod.INSTANCE, context.getWorld(), Vec3d.ofCenter(context.getAbsolutePos(fire)));
        } catch (ReflectiveOperationException e) { throw new RuntimeException(e); }
        context.runAtTick(50, () -> context.expectBlock(MeteorFire.BLOCK, fire));
        context.runAtTick(180, () -> {
            context.expectBlock(Blocks.AIR, fire);
            context.expectBlock(Blocks.OAK_PLANKS, new BlockPos(1, 1, 1));
            context.expectBlock(Blocks.OAK_PLANKS, new BlockPos(2, 2, 1));
            context.complete();
        });
    }

    @GameTest(templateName = FabricGameTest.EMPTY_STRUCTURE, tickLimit = 120)
    public void droppedEggImmuneToDamageAndExplosion(TestContext context) {
        ItemEntity item = floatingEgg(context);
        Vec3d before = item.getPos();
        var damage = context.getWorld().getDamageSources();
        context.assertTrue(!item.damage(damage.generic(), 1000), "Generic damage must be rejected immediately");
        context.assertTrue(!item.damage(damage.lava(), 1000), "Lava must not destroy egg");
        context.assertTrue(!item.damage(damage.inFire(), 1000), "Fire must not destroy egg");
        context.assertTrue(item.isFireImmune(), "Egg must be fireproof");
        context.assertTrue(item.isImmuneToExplosion(null), "Egg must reject explosion damage and knockback");
        context.getWorld().createExplosion(null, before.x, before.y, before.z, 4, net.minecraft.world.World.ExplosionSourceType.NONE);
        context.runAtTick(30, () -> {
            context.assertTrue(item.isAlive() && item.getStack().getCount() == 1, "Explosion or environment destroyed egg");
            context.assertTrue(item.getPos().squaredDistanceTo(before) < .01, "Explosion moved hovering egg");
            item.discard(); context.complete();
        });
    }
}
