package de.lenlive.dragonfury;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.api.EnvType;
public final class ClientMixinCheck implements PreLaunchEntrypoint {
    public void onPreLaunch() {
        if (FabricLoader.getInstance().getEnvironmentType() != EnvType.CLIENT || !Boolean.getBoolean("dragonfury.clientMixinCheck")) return;
        try {
            ClassLoader loader = getClass().getClassLoader();
            Class.forName("net.minecraft.client.render.entity.ItemEntityRenderer", false, loader);
            Class.forName("de.lenlive.dragonfury.client.DragonFuryClient", false, loader);
            Class.forName("net.minecraft.client.MinecraftClient", false, loader);
            Class.forName("net.minecraft.client.render.entity.LightningEntityRenderer", false, loader);
            System.out.println("DRAGONFURY_CLIENT_MIXINS_OK");
            System.exit(0);
        } catch (ClassNotFoundException e) { throw new RuntimeException(e); }
    }
}
