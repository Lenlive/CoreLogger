package de.lenlive.dragonfury;
import net.minecraft.block.*;
import net.minecraft.registry.*;
import net.minecraft.util.Identifier;
public final class MeteorFire {
    public static final MeteorFireBlock BLOCK = new MeteorFireBlock(AbstractBlock.Settings.copy(Blocks.FIRE));
    public static void initialize() { Registry.register(Registries.BLOCK, Identifier.of("dragonfury", "meteor_fire"), BLOCK); }
}
