package de.lenlive.dragonfury.client;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.entity.decoration.DisplayEntity;
import java.util.*;
/** Hide a dropped source item only while its replacement display is tracked by this client. */
public final class DragonFuryClient implements ClientModInitializer {
    private static volatile Set<UUID> hiddenItems = Set.of();
    public static boolean hides(UUID item) { return hiddenItems.contains(item); }
    @Override public void onInitializeClient() {
        EggGlowClient.initialize();
        net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap.INSTANCE.putBlock(
            de.lenlive.dragonfury.MeteorFire.BLOCK, net.minecraft.client.render.RenderLayer.getCutout());
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            Set<UUID> items = new HashSet<>();
            if (client.world != null) for (var entity : client.world.getEntities()) {
                if (!(entity instanceof DisplayEntity.BlockDisplayEntity) || entity.isRemoved() || entity.getCustomName() == null) continue;
                String name = entity.getCustomName().getString();
                try {
                    if (name.startsWith("dragonfury:item:")) items.add(UUID.fromString(name.substring(16)));
                } catch (IllegalArgumentException ignored) { }
            }
            hiddenItems = Set.copyOf(items);
        });
    }
}
