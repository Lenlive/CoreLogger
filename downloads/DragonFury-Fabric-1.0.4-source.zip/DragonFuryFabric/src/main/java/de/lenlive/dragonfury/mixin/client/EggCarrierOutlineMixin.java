package de.lenlive.dragonfury.mixin.client;
import de.lenlive.dragonfury.client.EggGlowClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(MinecraftClient.class)
public abstract class EggCarrierOutlineMixin {
    @Inject(method = "hasOutline", at = @At("RETURN"), cancellable = true)
    private void dragonfury$visibleCarrier(Entity entity, CallbackInfoReturnable<Boolean> ci) {
        if (!ci.getReturnValue() && EggGlowClient.visibleCarrier((MinecraftClient)(Object)this, entity)) ci.setReturnValue(true);
    }
}
