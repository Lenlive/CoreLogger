package de.lenlive.dragonfury.mixin;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(ItemEntity.class)
public abstract class EggDamageMixin {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void dragonfury$immune(DamageSource source, float amount, CallbackInfoReturnable<Boolean> ci) {
        if (((ItemEntity)(Object)this).getStack().isOf(Items.DRAGON_EGG)) ci.setReturnValue(false);
    }
    @Inject(method = "isFireImmune", at = @At("HEAD"), cancellable = true)
    private void dragonfury$fireproof(CallbackInfoReturnable<Boolean> ci) {
        if (((ItemEntity)(Object)this).getStack().isOf(Items.DRAGON_EGG)) ci.setReturnValue(true);
    }
    @Inject(method = "tick", at = @At("HEAD"))
    private void dragonfury$protectDrop(CallbackInfo ci) {
        ItemEntity item = (ItemEntity)(Object)this;
        if (item.getWorld().isClient || !item.getStack().isOf(Items.DRAGON_EGG)) return;
        item.setInvulnerable(true); item.setNoGravity(true); item.setNeverDespawn();
        item.setVelocity(net.minecraft.util.math.Vec3d.ZERO); item.extinguish();
        if (item.getY() < item.getWorld().getBottomY() + 1)
            item.refreshPositionAfterTeleport(item.getX(), item.getWorld().getBottomY() + 2, item.getZ());
    }
}
