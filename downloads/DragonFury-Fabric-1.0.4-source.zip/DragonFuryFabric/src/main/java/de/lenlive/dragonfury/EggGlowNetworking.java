package de.lenlive.dragonfury;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.item.Items;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import java.util.*;
final class EggGlowNetworking {
    private static final Set<UUID> carriers = new HashSet<>();
    static void initialize() {
        PayloadTypeRegistry.playS2C().register(EggGlowPayload.ID, EggGlowPayload.CODEC);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList())
                if (player.getInventory().count(Items.DRAGON_EGG) > 0) send(handler.player, player.getUuid(), true);
        });
    }
    private static void send(ServerPlayerEntity viewer, UUID carrier, boolean active) {
        if (ServerPlayNetworking.canSend(viewer, EggGlowPayload.ID))
            ServerPlayNetworking.send(viewer, new EggGlowPayload(carrier, active));
    }
    static boolean isCarrier(UUID player) { return carriers.contains(player); }
    static void tick(MinecraftServer server) {
        Set<UUID> current = new HashSet<>();
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList())
            if (player.isAlive() && player.getInventory().count(Items.DRAGON_EGG) > 0) current.add(player.getUuid());
        Set<UUID> changed = new HashSet<>(carriers); changed.addAll(current);
        for (UUID id : changed) if (carriers.contains(id) != current.contains(id))
            for (ServerPlayerEntity viewer : server.getPlayerManager().getPlayerList()) send(viewer, id, current.contains(id));
        carriers.clear(); carriers.addAll(current);
    }
    static void clear() { carriers.clear(); }
}
