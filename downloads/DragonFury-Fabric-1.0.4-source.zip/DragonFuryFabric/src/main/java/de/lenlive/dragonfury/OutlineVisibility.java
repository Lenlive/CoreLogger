package de.lenlive.dragonfury;
import net.minecraft.entity.Entity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
public final class OutlineVisibility {
    private OutlineVisibility() {}
    public static boolean hasClearSight(BlockView world, Vec3d camera, Box bounds, Entity viewer) {
        for (double x : new double[]{bounds.minX, bounds.maxX})
            for (double y : new double[]{bounds.minY, bounds.maxY})
                for (double z : new double[]{bounds.minZ, bounds.maxZ}) {
                    var ray = world.raycast(new RaycastContext(camera, new Vec3d(x, y, z),
                        RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, viewer));
                    if (ray.getType() != HitResult.Type.MISS) return false;
                }
        return world.raycast(new RaycastContext(camera, bounds.getCenter(), RaycastContext.ShapeType.COLLIDER,
            RaycastContext.FluidHandling.NONE, viewer)).getType() == HitResult.Type.MISS;
    }
}
