package de.lenlive.dragonfury.mixin;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Items;
import net.minecraft.world.explosion.Explosion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
@Mixin(Entity.class)
public abstract class EggExplosionMixin {
    @Inject(method = "isImmuneToExplosion", at = @At("HEAD"), cancellable = true)
    private void dragonfury$explosionproof(Explosion explosion, CallbackInfoReturnable<Boolean> ci) {
        if ((Object)this instanceof ItemEntity item && item.getStack().isOf(Items.DRAGON_EGG)) ci.setReturnValue(true);
    }
}
