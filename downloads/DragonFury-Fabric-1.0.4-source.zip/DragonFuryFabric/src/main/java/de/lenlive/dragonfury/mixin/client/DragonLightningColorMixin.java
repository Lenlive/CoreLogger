package de.lenlive.dragonfury.mixin.client;
import net.minecraft.client.render.entity.LightningEntityRenderer;
import net.minecraft.entity.LightningEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
@Mixin(LightningEntityRenderer.class)
public abstract class DragonLightningColorMixin {
    @Unique private boolean dragonfury$colored;
    @Inject(method = "render(Lnet/minecraft/entity/LightningEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V", at = @At("HEAD"))
    private void dragonfury$identify(LightningEntity bolt, float yaw, float tickDelta, MatrixStack matrices,
            VertexConsumerProvider vertices, int light, CallbackInfo ci) {
        dragonfury$colored = bolt.getCustomName() != null && bolt.getCustomName().getString().equals("dragonfury:lightning");
    }
    @ModifyArgs(method = "render(Lnet/minecraft/entity/LightningEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/LightningEntityRenderer;drawBranch(Lorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumer;FFIFFFFFFFZZZZ)V"))
    private void dragonfury$violet(Args args) {
        if (dragonfury$colored) { args.set(7, .85f); args.set(8, .08f); args.set(9, 1.0f); }
    }
}
