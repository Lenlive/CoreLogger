package de.lenlive.dragonfury;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;
import java.util.UUID;
public record EggGlowPayload(UUID player, boolean active) implements CustomPayload {
    public static final Id<EggGlowPayload> ID = new Id<>(Identifier.of("dragonfury", "egg_glow"));
    public static final PacketCodec<RegistryByteBuf, EggGlowPayload> CODEC = PacketCodec.tuple(
        Uuids.PACKET_CODEC, EggGlowPayload::player, PacketCodecs.BOOL, EggGlowPayload::active, EggGlowPayload::new);
    public Id<? extends CustomPayload> getId() { return ID; }
}
