package de.lenlive.dragonfury;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.*;
/** Real damaging fire that never spreads, burns blocks or lights portals. Its expiry tick persists with the chunk. */
public final class MeteorFireBlock extends AbstractFireBlock {
    public static final MapCodec<MeteorFireBlock> CODEC = createCodec(MeteorFireBlock::new);
    public MeteorFireBlock(Settings settings) { super(settings, 1.0f); }
    protected MapCodec<MeteorFireBlock> getCodec() { return CODEC; }
    protected boolean isFlammable(BlockState state) { return false; }
    protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        return world.getBlockState(pos.down()).isSideSolidFullSquare(world, pos.down(), Direction.UP);
    }
    protected BlockState getStateForNeighborUpdate(BlockState state, Direction direction, BlockState neighborState,
            WorldAccess world, BlockPos pos, BlockPos neighborPos) {
        return canPlaceAt(state, world, pos) ? state : Blocks.AIR.getDefaultState();
    }
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState previous, boolean notify) {
        if (!previous.isOf(this)) world.scheduleBlockTick(pos, this, 160);
    }
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (state.isOf(this)) world.setBlockState(pos, Blocks.AIR.getDefaultState());
    }
}
