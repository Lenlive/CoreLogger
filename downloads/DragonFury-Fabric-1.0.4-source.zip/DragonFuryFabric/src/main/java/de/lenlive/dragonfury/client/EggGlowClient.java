package de.lenlive.dragonfury.client;
import de.lenlive.dragonfury.EggGlowPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import java.util.*;
public final class EggGlowClient {
    private static final Set<UUID> carriers = new HashSet<>();
    public static void initialize() {
        ClientPlayNetworking.registerGlobalReceiver(EggGlowPayload.ID, (payload, context) -> context.client().execute(() -> {
            if (payload.active()) carriers.add(payload.player()); else carriers.remove(payload.player());
        }));
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> carriers.clear());
    }
    public static boolean visibleCarrier(MinecraftClient client, Entity entity) {
        if (!(entity instanceof PlayerEntity) || !entity.isAlive() || entity.isInvisible() ||
            !carriers.contains(entity.getUuid()) || client.world == null || client.player == null) return false;
        Vec3d camera = client.gameRenderer.getCamera().getPos();
        Box bounds = entity.getBoundingBox().contract(.08);
        return de.lenlive.dragonfury.OutlineVisibility.hasClearSight(client.world, camera, bounds, client.player);
    }
}
